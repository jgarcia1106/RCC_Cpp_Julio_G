# Project 2 - Pac-Man Game Development

## 1.5
- Fixed infinite lives and end games message

## 1.4
- Added the end game message

## 1.3
- Updated variables to 7 characters

## 1.2
- Added comments to the pac-man program