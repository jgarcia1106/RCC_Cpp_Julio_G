/* 
 * File:   main.cpp
 * Author: Julio G.
 * Created on January 3, 2024, 7:39 PM
 * Purpose: Template used to start all projects
 */

//System Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Libraries

//Global Constants - Math,Physics,Chemistry,Conversions7

//Function Prototypes

//Program-Execution Begins Here

int main(int argc, char** argv) {
    //Set a random seed
    
    //Declare all variables
    
    //Initialize all variables
    
    //Process or Map solutions
    
    //Display the output
    
    //Exit the Program
    return 0;
}

